#include <iostream>
using namespace std;

void menu()
{
	cout << endl;
	cout << "\t\t"<< "*****WELCOME TO MASTERMIND GUESSING GAME*****" << "\t\t" << endl;
	cout << "\nMAIN MENU : " << endl;
	cout << "\n1 - START" << endl;
	cout << "\n2 - INSTRUCTION" << endl;
	cout << "\n3 - HIGH SCORE" << endl;
	cout << "\n4 - EXIT" << endl;
}
